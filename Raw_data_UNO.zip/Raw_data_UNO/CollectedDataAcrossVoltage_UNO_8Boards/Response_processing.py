# -*- coding: utf-8 -*-
"""
Created on Tue Jan 18 04:58:28 2022

@author: Thermal Chamber
"""
import glob, os
import numpy as np
import re
import matplotlib.pyplot as plt
import copy
import os


path = ''
path_resp = ''
sram_puf_response_files = [f for f in os.listdir() if f.startswith('resp_SRAMPUF') and f.endswith('.csv')]
print(sram_puf_response_files)

#%%
ambientTemp = 25
nMeasMax = 1
#This is the size of the SRAM PUF

Volt_all = np.array([3.8,3.9,4,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,5,
                     5.1,5.2,5.3,5.4,5.5,5.6,5.7,5.8,5.9,6,6.1,6.2])
Board_all = np.array([21,23,25,27,30,36,38,39])

PUF_response = np.zeros([8,len(Volt_all),128,64])

for file_aval in sram_puf_response_files:
    BrId = int((re.findall('\d+',file_aval))[2])
    Volt = int((re.findall('\d+',file_aval))[3])
    if(len(re.findall('\d+',file_aval))==5):
        Volt = Volt + int((re.findall('\d+',file_aval))[4])*0.1
    print('Volt',Volt,'BrId',BrId)
    Voltloc = np.where(Volt_all==Volt)[0][0]
    Boardloc = np.where(Board_all==BrId)[0][0]
    PUF_response[Boardloc,Voltloc,:,:] = np.reshape(np.genfromtxt(path+file_aval,delimiter=',')[:,1:9],[128,64])


GRespFile = path_resp+'GResp_UNO_Volt_all.npy'

np.save(GRespFile,PUF_response)

print(np.sum(np.sum(PUF_response,axis=3),axis=2)/(128*64)*100)