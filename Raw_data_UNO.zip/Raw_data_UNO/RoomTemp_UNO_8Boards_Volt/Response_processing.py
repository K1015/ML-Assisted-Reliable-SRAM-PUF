    # -*- coding: utf-8 -*-
"""

@author: imperialSF
"""
import glob, os
import numpy as np
import re
import matplotlib.pyplot as plt
import copy
import os


from os import chdir, getcwd
wd=getcwd()
chdir(wd)

sram_puf_response_files = [f for f in os.listdir() if f.startswith('resp_SRAMPUF') and f.endswith('.csv')]
print(sram_puf_response_files)

#%%
nMeasMax = 15
Volt_all = np.array([5])
nChal = 1024
respW = 8
Board_all = np.array([21,23,25,27,30,36,38,39])

PUF_response = np.zeros([len(Board_all),nChal,respW,nMeasMax])
Reliability_PUF = np.zeros([len(Board_all),nChal,respW])
Golden_PUF_response = np.zeros([len(Board_all),nChal,respW])

for file_aval in sram_puf_response_files:
    Volt = int((re.findall('\d+',file_aval))[3])
    nMeas = int((re.findall('\d+',file_aval))[1])
    BrId = int((re.findall('\d+',file_aval))[2])
    print('Volt',Volt,'nMeas',nMeas,'BrId',BrId)
    Boardloc = np.where(Board_all==BrId)[0]
    PUF_response[Boardloc,:,:,nMeas] = np.genfromtxt(file_aval,delimiter=',')[:,1:9]

#%%
from scipy.stats import mode

Reliability_PUF = np.zeros([len(Board_all),nChal,respW])
Golden_PUF_response = np.zeros([len(Board_all),nChal,respW])
for i in range(len(Board_all)):
    Reliability_PUF[i,:,:] = np.sum(PUF_response[i,:,:,:],axis=2) 
    Reliability_PUF[i,:,:] = (Reliability_PUF[i,:,:]/nMeasMax)*100
    for k in range(nChal):
        for l in range(respW):
            if(Reliability_PUF[i,k,l]<=50):
                Reliability_PUF[i,k,l] = 100 - Reliability_PUF[i,k,l]
            Golden_PUF_response[i,k,l] = mode(PUF_response[i,k,l,:])[0]  

#%%
RespFile = 'Resp_UNO_AmbientVolt_nMeas'+str(nMeasMax)+'.npy'
 
np.save(RespFile,PUF_response)

GRespFile = 'GResp_UNO_AmbientVolt_nMeas'+str(nMeasMax)+'.npy'

np.save(GRespFile,Golden_PUF_response)

RelFile = 'Rel_UNO_AmbientVolt_nMeas'+str(nMeasMax)+'.npy'

np.save(RelFile,Reliability_PUF)

#%%
#Visual Representation
plt.axis('off')
plt.imshow(Golden_PUF_response[0,:,:].reshape(128,8*8), cmap='Greys',  interpolation='nearest', aspect='equal')
#plt.colorbar()
plt.show()
