#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  8 01:48:23 2022

@author: imperialSF
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial.distance import hamming
from scipy.spatial.distance import pdist,squareform
import matplotlib.pyplot as plt
import glob
import os
import re
import math

def nCr(n,r):
    f = math.factorial
    return f(n) // f(r) // f(n-r)

font = {'family': 'arial',
        'color':  'black',
        'weight': 'bold',
        'size': 16,
        }

from os import chdir, getcwd
wd=getcwd()
chdir(wd)

nMeasMax = 15
nChal = 1024
respW = 8
BoardTotal = 8
Board_all = np.array([21,23,25,27,30,36,38,39])
Uniformity = np.zeros([len(Board_all)])

GRespFile = 'GResp_UNO_AmbientVolt_nMeas'+str(nMeasMax)+'.npy'
RespFile = 'Resp_UNO_AmbientVolt_nMeas'+str(nMeasMax)+'.npy'
#%%
#Finding Uniformity
for bid in range(len(Board_all)):
    GResp = np.load(GRespFile)[bid,:,:]
    GResp = GResp.reshape([nChal*respW])
    Uniformity[bid] = (np.sum(GResp)/(nChal*respW))*100

print('Uniformity:',Uniformity)

#%%        
fig, ax = plt.subplots(figsize=(10,6))
plt.yticks(fontname = "Arial") 
plt.xticks(fontname = "Arial") 
plt.ylim([55, 70])
plt.ylabel('Unifomity (%)',fontsize=36,fontdict=font, fontweight = "bold")
plt.xlabel('# of PUF instances',fontsize=36,fontdict=font, fontweight = "bold")
ax.scatter(np.arange(BoardTotal), (Uniformity),marker="o",s=300,color='purple',alpha=0.6)
ax.xaxis.set_tick_params(labelsize=32)
ax.yaxis.set_tick_params(labelsize=32)
ax.set_axisbelow(True)
ax.grid(True)

#%%
Reliability = np.zeros([len(Board_all),nMeasMax])

for bid in range(len(Board_all)):
    GResp = np.load(GRespFile)[bid,:,:]
    Resp = np.load(RespFile)[bid,:,:,:]
    for i in range(nMeasMax):
        rel = 0
        for j in range(nChal):
            for k in range(respW):
                if(GResp[j,k]==Resp[j,k,i]):
                    rel = rel+1
        Reliability[bid,i] = (rel/(nChal*respW))*100

#print(Reliability)        
Reliability_avg = np.average(Reliability,axis=1)
print('Total Reliability:',Reliability_avg)

#%%
BoardNo = np.arange(8)
comb_array = np.array(np.meshgrid(BoardNo, BoardNo)).T.reshape(-1, 2)
Fractional_HD = np.zeros(len(comb_array))

for i in range(len(comb_array)):
    Resp1 = np.load(GRespFile)[comb_array[i][0],:,:]
    Resp2 = np.load(GRespFile)[comb_array[i][1],:,:]
    Resp1 = Resp1.reshape([nChal*respW])
    Resp2 = Resp2.reshape([nChal*respW])
    Fractional_HD[i] = hamming(Resp1, Resp2)
    
Fractional_HD = Fractional_HD[Fractional_HD!=0]*100
Uniqueness = np.mean(Fractional_HD)
print(Uniqueness)

#%%
fig, ax = plt.subplots(figsize=(10,6))
plt.yticks(fontname = "Arial") 
plt.xticks(fontname = "Arial") 
plt.ylabel('# of occurences',fontsize=36,fontdict=font, fontweight = "bold")
plt.xlabel('Fractional Hamming Distance (%)',fontsize=36,fontdict=font, fontweight = "bold")
plt.hist(Fractional_HD, bins= np.arange(min(Fractional_HD), max(Fractional_HD) + 1, 0.5), density=False,
          histtype='bar',
          color='purple',
          edgecolor='purple',
          alpha=0.6)
ax.xaxis.set_tick_params(labelsize=32)
ax.yaxis.set_tick_params(labelsize=32)
ax.set_axisbelow(True)
ax.grid(True)
